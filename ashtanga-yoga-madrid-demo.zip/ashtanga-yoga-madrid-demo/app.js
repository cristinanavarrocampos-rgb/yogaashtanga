(function () {
  'use strict';
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const store = {
    get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* sin almacenamiento */ } }
  };

  /* ---------- Datos: horario real publicado por la escuela (septiembre 2025) ---------- */
  const DAYS = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
  const TEACHERS = ['Borja', 'Anna', 'Thanh', 'Daniela'];
  const WEEK = [
    [['06:30', '09:00', 'Mysore', 'Borja, Anna'], ['19:00', '21:00', 'Mysore', 'Borja']],
    [['06:30', '09:00', 'Mysore', 'Borja, Anna'], ['10:00', '12:00', 'Mysore', 'Anna'], ['19:00', '21:00', 'Mysore', 'Borja']],
    [['06:30', '09:00', 'Mysore', 'Borja, Anna'], ['14:00', '16:00', 'Mysore', 'Thanh'], ['19:00', '21:00', 'Guiada / Mysore', 'Borja']],
    [['06:30', '09:00', 'Mysore', 'Anna'], ['19:00', '21:00', 'Mysore', 'Thanh']],
    [['06:30', '09:00', 'Mysore', 'Anna'], ['10:00', '12:00', 'Mysore', 'Anna'], ['17:00', '19:00', 'Mysore', 'Thanh']],
    [['06:30', '11:00', 'Mysore', 'Borja, Anna, Daniela'], ['11:00', '13:00', 'Guiada', 'Borja, Thanh, Daniela']],
    [['11:00', '13:00', 'Mysore', 'Borja, Thanh, Anna']]
  ];

  /* Fechas de ejemplo para la demo: sustituir por las reales de la escuela. */
  function nthWeekday(y, m, weekday, n) {
    const d = new Date(y, m, 1);
    const offset = (weekday - d.getDay() + 7) % 7;
    return new Date(y, m, 1 + offset + (n - 1) * 7);
  }
  const EVENTS = {
    iniciacion: {
      label: 'iniciación',
      book: 'Taller de introducción · 20 €',
      forMonth(y, m) {
        return [{ start: nthWeekday(y, m, 0, 1), end: null, title: 'Taller de introducción', info: '13:15 · 90 minutos · 20 €' }];
      }
    },
    talleres: {
      label: 'talleres',
      book: 'Tengo una consulta',
      forMonth(y, m) {
        return [{ start: nthWeekday(y, m, 6, 3), end: null, title: 'Taller temático', info: 'Tarde · plazas limitadas' }];
      }
    },
    retiros: {
      label: 'retiros',
      book: 'Tengo una consulta',
      forMonth(y, m) {
        return m === 4 ? [{ start: nthWeekday(y, m, 0, 1), end: new Date(y, m, nthWeekday(y, m, 0, 1).getDate() + 6), title: 'Retiro de una semana', info: 'Con Borja Romero · plazas limitadas' }] : [];
      }
    }
  };

  const fmtMonth = new Intl.DateTimeFormat('es-ES', { month: 'long', year: 'numeric' });
  const fmtDay = new Intl.DateTimeFormat('es-ES', { weekday: 'long', day: 'numeric', month: 'long' });
  const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
  const dayIdx = d => (d.getDay() + 6) % 7;
  const sameDay = (a, b) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
  const teacherClass = t => 'c-' + t.split(',')[0].trim().toLowerCase();
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  /* ---------- Próxima clase ---------- */
  (function nextClass() {
    const now = new Date();
    const hm = now.toTimeString().slice(0, 5);
    const idx = dayIdx(now);
    let text = '';
    for (let i = 0; i < 7 && !text; i++) {
      const list = WEEK[(idx + i) % 7];
      const c = i === 0 ? list.find(k => k[0] > hm) : list[0];
      if (c) {
        const when = i === 0 ? 'hoy' : i === 1 ? 'mañana' : 'el ' + DAYS[(idx + i) % 7].toLowerCase();
        text = 'Próxima clase: ' + when + ' a las ' + c[0] + ' · ' + c[2];
      }
    }
    $('#todayLine').textContent = text;
  })();

  /* ---------- Calendarios ---------- */
  const cal = $('#calendar');
  const state = { tab: 'semana', teacher: 'Todos', view: new Date(today.getFullYear(), today.getMonth(), 1), sel: new Date(today) };

  function renderWeek() {
    const filters = ['Todos'].concat(TEACHERS).map(t =>
      `<button type="button" data-teacher="${t}" aria-pressed="${state.teacher === t}">${t}</button>`).join('');
    const days = DAYS.map((name, i) => {
      const list = WEEK[i].filter(c => state.teacher === 'Todos' || c[3].includes(state.teacher));
      const body = list.length ? list.map(c => classButton(c, name)).join('') : '<p class="empty">Sin clases</p>';
      return `<div class="day${i === dayIdx(today) ? ' day--today' : ''}${list.length ? '' : ' day--empty'}"><h3>${name}</h3><div>${body}</div></div>`;
    }).join('');
    cal.innerHTML = `<div class="filters"><span>Profesor:</span>${filters}</div><div class="week">${days}</div>`;
  }

  function classButton(c, dayName) {
    const label = `${dayName} ${c[0]} · ${c[2]}`;
    return `<button type="button" class="cls ${teacherClass(c[3])}" data-class="${label}" aria-label="Reservar ${label} con ${c[3]}"><b>${c[0]}–${c[1]}</b><i>${c[2]}</i>${c[3]}</button>`;
  }

  function eventsOf(tab, y, m) {
    if (tab === 'mes') return null;
    return EVENTS[tab].forMonth(y, m);
  }
  function dayHasEvent(list, d) {
    return list.filter(e => e.end ? d >= e.start && d <= e.end : sameDay(e.start, d));
  }

  function renderMonth() {
    const y = state.view.getFullYear(), m = state.view.getMonth();
    const first = new Date(y, m, 1), total = new Date(y, m + 1, 0).getDate();
    const list = eventsOf(state.tab, y, m);
    let cells = ['L', 'M', 'X', 'J', 'V', 'S', 'D'].map(d => `<span>${d}</span>`).join('');
    for (let i = 0; i < dayIdx(first); i++) cells += '<i></i>';
    for (let n = 1; n <= total; n++) {
      const d = new Date(y, m, n);
      const has = list ? dayHasEvent(list, d).length > 0 : WEEK[dayIdx(d)].length > 0;
      const cls = [has ? 'has' : '', sameDay(d, today) ? 'today' : ''].join(' ').trim();
      cells += `<button type="button" data-day="${n}" class="${cls}" aria-pressed="${sameDay(d, state.sel)}" aria-label="${fmtDay.format(d)}">${n}</button>`;
    }
    cal.innerHTML = `<div class="month"><div>
        <div class="month__bar"><button type="button" data-nav="-1" aria-label="Mes anterior">‹</button><h3>${cap(fmtMonth.format(first))}</h3><button type="button" data-nav="1" aria-label="Mes siguiente">›</button></div>
        <div class="grid">${cells}</div>
      </div><div class="list" aria-live="polite">${renderList(list, y, m)}</div></div>`;
  }

  function renderList(list, y, m) {
    if (!list) {
      const c = WEEK[dayIdx(state.sel)];
      return `<h4>${cap(fmtDay.format(state.sel))}</h4>` + c.map(k =>
        `<div class="item ${teacherClass(k[3])}"><b>${k[0]}–${k[1]} · ${k[2]}</b>${k[3]}<br><button type="button" class="btn btn--small" data-class="${DAYS[dayIdx(state.sel)]} ${k[0]} · ${k[2]}">Reservar</button></div>`).join('');
    }
    const ev = EVENTS[state.tab];
    if (!list.length) {
      const next = nextEventMonth(y, m);
      return `<h4>${cap(ev.label)}</h4><p>No hay ${ev.label} este mes.</p>` + (next ? `<button type="button" class="btn btn--ghost btn--small jump" data-goto="${next.getFullYear()}-${next.getMonth()}">Ver el próximo: ${fmtMonth.format(next)}</button>` : '');
    }
    return `<h4>${cap(ev.label)}</h4>` + list.map(e => {
      const when = e.end ? `Del ${e.start.getDate()} al ${e.end.getDate()} de ${new Intl.DateTimeFormat('es-ES', { month: 'long' }).format(e.start)}` : cap(fmtDay.format(e.start));
      return `<div class="item"><span class="badge">Fecha de ejemplo</span><b>${e.title}</b>${when}<br>${e.info}<br><button type="button" class="btn btn--small" data-class="${e.title}" data-book-as="${ev.book}">Pedir plaza</button></div>`;
    }).join('');
  }
  function nextEventMonth(y, m) {
    for (let i = 1; i <= 12; i++) {
      const d = new Date(y, m + i, 1);
      if (EVENTS[state.tab].forMonth(d.getFullYear(), d.getMonth()).length) return d;
    }
    return null;
  }

  function render() { state.tab === 'semana' ? renderWeek() : renderMonth(); }

  $$('.tabs button').forEach(b => b.addEventListener('click', () => {
    $$('.tabs button').forEach(x => x.setAttribute('aria-selected', x === b));
    state.tab = b.dataset.tab;
    state.view = new Date(today.getFullYear(), today.getMonth(), 1);
    state.sel = new Date(today);
    render();
  }));

  cal.addEventListener('click', e => {
    const t = e.target.closest('button');
    if (!t) return;
    if (t.dataset.teacher) { state.teacher = t.dataset.teacher; renderWeek(); return; }
    if (t.dataset.nav) {
      state.view = new Date(state.view.getFullYear(), state.view.getMonth() + Number(t.dataset.nav), 1);
      state.sel = new Date(state.view);
      renderMonth(); return;
    }
    if (t.dataset.goto) {
      const [y, m] = t.dataset.goto.split('-').map(Number);
      state.view = new Date(y, m, 1); state.sel = new Date(y, m, 1);
      renderMonth(); return;
    }
    if (t.dataset.day) {
      state.sel = new Date(state.view.getFullYear(), state.view.getMonth(), Number(t.dataset.day));
      renderMonth(); return;
    }
    if (t.dataset.class) book(t.dataset.bookAs, 'Me interesa: ' + t.dataset.class);
  });
  render();

  /* ---------- Reservas (dentro de la misma página) ---------- */
  const what = $('#bookWhat'), msg = $('#bookMsg');
  function book(option, note) {
    if ($$('option', what).some(o => o.value === option)) what.value = option;
    if (note) msg.value = note;
    $('#reservar').scrollIntoView({ behavior: reduced ? 'auto' : 'smooth' });
    setTimeout(() => $('input[name=nombre]').focus({ preventScroll: true }), reduced ? 0 : 650);
  }
  $$('[data-book]').forEach(a => a.addEventListener('click', e => { e.preventDefault(); book(a.dataset.book); }));

  const form = $('#bookForm'), fm = $('#formMsg');
  form.addEventListener('submit', e => {
    e.preventDefault();
    let bad = null;
    $$('input[required]', form).forEach(i => {
      const target = i.type === 'checkbox' ? i.closest('.check') : i;
      const ok = i.type === 'checkbox' ? i.checked : i.value.trim().length > 1;
      target.classList.toggle('invalid', !ok);
      i.setAttribute('aria-invalid', String(!ok));
      if (!ok && !bad) bad = i;
    });
    const mail = form.elements.email;
    const mailOk = !mail.value || mail.checkValidity();
    mail.classList.toggle('invalid', !mailOk);
    if (!mailOk && !bad) bad = mail;
    if (bad) {
      fm.className = 'form__msg err';
      fm.textContent = 'Revisa los campos marcados: nombre, teléfono y aceptación de la política de privacidad.';
      bad.focus();
      return;
    }
    fm.className = 'form__msg';
    fm.textContent = 'Solicitud de demostración recibida. En esta demo no se ha enviado ningún dato.';
    form.reset();
  });

  /* ---------- Calculadora de bonos ---------- */
  const PLANS = [
    { n: 5, p: 60, name: 'Bono mensual de 5 clases', opt: 'Bono mensual · 5 clases · 60 €' },
    { n: 9, p: 85, name: 'Bono mensual de 9 clases', opt: 'Bono mensual · 9 clases · 85 €' },
    { n: 13, p: 100, name: 'Bono mensual de 13 clases', opt: 'Bono mensual · 13 clases · 100 €' },
    { n: Infinity, p: 115, name: 'Bono mensual ilimitado', opt: 'Bono mensual · Ilimitado · 115 €' }
  ];
  const range = $('#calcRange');
  const money = v => (Math.round(v * 100) / 100).toLocaleString('es-ES', { maximumFractionDigits: 2 }) + ' €';
  function calc() {
    const n = Number(range.value);
    let best = n * 18 <= 60 && n < 4 ? { p: n * 18, name: n === 1 ? '1 clase suelta' : n + ' clases sueltas', opt: '1 clase suelta · 18 €' } : null;
    PLANS.forEach(pl => { if (pl.n >= n && (!best || pl.p < best.p)) best = pl; });
    $('#calcCount').textContent = n;
    $('#calcName').textContent = best.name;
    $('#calcPrice').textContent = money(best.p) + ' al mes · ' + money(best.p / n) + ' por clase';
    $('#calcBtn').dataset.opt = best.opt;
  }
  range.addEventListener('input', calc);
  $('#calcBtn').addEventListener('click', e => { e.preventDefault(); book(e.currentTarget.dataset.opt); });
  calc();

  /* ---------- Menú móvil ---------- */
  const toggle = $('#navToggle'), menu = $('#navMenu');
  toggle.addEventListener('click', () => {
    const open = menu.classList.toggle('open');
    toggle.setAttribute('aria-expanded', open);
    toggle.textContent = open ? 'Cerrar' : 'Menú';
  });
  menu.addEventListener('click', e => {
    if (e.target.closest('a')) { menu.classList.remove('open'); toggle.setAttribute('aria-expanded', false); toggle.textContent = 'Menú'; }
  });

  /* ---------- Textos legales ---------- */
  const LEGAL = {
    cookies: '<h2>Política de cookies</h2><p><b>Necesarias.</b> Guardamos tu elección en este navegador para no volver a preguntarte. No requieren consentimiento.</p><p><b>Mapa.</b> Si lo aceptas, se carga el mapa de Google, que puede instalar sus propias cookies.</p><p><b>Estadística.</b> Categoría preparada para medir visitas. No se carga ningún servicio de estadística en esta demo.</p><p>Puedes cambiar tu elección cuando quieras desde «Configurar cookies», al final de la página.</p>',
    privacidad: '<h2>Política de privacidad</h2><p>Texto pendiente: antes de publicar, debe incorporarse aquí la política vigente de Ashtanga Yoga Madrid.</p><p>En esta demo, el formulario de reserva no envía ni guarda ningún dato.</p>',
    aviso: '<h2>Aviso legal</h2><p>Texto pendiente: antes de publicar, debe incorporarse aquí el aviso legal vigente de Ashtanga Yoga Madrid.</p>'
  };
  const dlg = $('#legal');
  document.addEventListener('click', e => {
    const b = e.target.closest('[data-legal]');
    if (!b) return;
    $('#legalBody').innerHTML = LEGAL[b.dataset.legal];
    dlg.showModal();
  });
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.close(); });

  /* ---------- Cookies y mapa ---------- */
  const bar = $('#cookieBar'), main = $('#cookieMain'), cfg = $('#cookieCfg');
  const KEY = 'aym-cookies';
  function readConsent() { try { return JSON.parse(store.get(KEY)); } catch (e) { return null; } }
  function loadMap() {
    const box = $('#mapBox');
    if ($('iframe', box)) return;
    box.innerHTML = '<iframe title="Mapa: Calle de Espoz y Mina 17, Madrid" loading="lazy" tabindex="-1" src="https://www.google.com/maps?q=Calle+de+Espoz+y+Mina+17,+28012+Madrid&output=embed"></iframe>';
  }
  function unloadMap() {
    const box = $('#mapBox');
    if (!$('iframe', box)) return;
    box.innerHTML = '<div class="map__ph"><p>El mapa usa un servicio de Google y solo se carga si lo aceptas.</p><button class="btn btn--ghost" id="mapAllow" type="button">Mostrar el mapa</button></div>';
  }
  function save(c) {
    store.set(KEY, JSON.stringify(c));
    bar.hidden = true;
    c.map ? loadMap() : unloadMap();
  }
  $('#ckAll').addEventListener('click', () => save({ map: true, stats: true }));
  $('#ckNone').addEventListener('click', () => save({ map: false, stats: false }));
  $('#ckCfg').addEventListener('click', () => {
    const c = readConsent() || {};
    $('#ckMap').checked = !!c.map; $('#ckStats').checked = !!c.stats;
    main.hidden = true; cfg.hidden = false;
  });
  cfg.addEventListener('submit', e => {
    e.preventDefault();
    save({ map: $('#ckMap').checked, stats: $('#ckStats').checked });
  });
  $('#cookieReopen').addEventListener('click', () => { main.hidden = false; cfg.hidden = true; bar.hidden = false; });
  document.addEventListener('click', e => {
    if (e.target.id === 'mapAllow') {
      const c = readConsent() || { stats: false };
      c.map = true; save(c);
    }
  });
  const consent = readConsent();
  if (consent) { if (consent.map) loadMap(); } else { bar.hidden = false; }

  /* ---------- Aparición y volumen 3D ---------- */
  const reveals = $$('.section__head, .offer, .method__img, .method__text, .calendar, .calc, .rates__col, .teacher, .reviews__score, .theme, .form, .book__intro, .contact__info, .map');
  if ('IntersectionObserver' in window && !reduced) {
    reveals.forEach(el => el.classList.add('reveal'));
    const io = new IntersectionObserver(es => es.forEach(en => {
      if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
    }), { threshold: 0.08, rootMargin: '0px 0px -30px' });
    reveals.forEach(el => io.observe(el));
  }

  if (matchMedia('(hover:hover) and (pointer:fine)').matches && !reduced) {
    $$('.tilt').forEach(el => {
      el.addEventListener('pointerenter', () => { el.style.transition = 'transform .12s linear'; });
      el.addEventListener('pointermove', e => {
        const r = el.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5;
        el.style.transform = `perspective(900px) rotateY(${x * 9}deg) rotateX(${-y * 9}deg) translateZ(14px)`;
      });
      el.addEventListener('pointerleave', () => { el.style.transition = ''; el.style.transform = ''; });
    });
  }

  /* ---------- Volumen 3D de la foto de portada ---------- */
  const photo = $('#heroPhoto');
  if (!reduced) {
    addEventListener('pointermove', e => {
      const x = e.clientX / innerWidth - .5, y = e.clientY / innerHeight - .5;
      photo.style.transform = `rotateY(${-9 + x * 12}deg) rotateX(${3 - y * 8}deg)`;
    }, { passive: true });
  }
})();
